import random

print("Random Number Generator")
number = random.randint(1, 100)
print("Your random number is:", number)
