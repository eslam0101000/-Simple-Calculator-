# Word Counter

text = input("Enter a sentence: ")
words = text.split()
print("Number of words:", len(words))
